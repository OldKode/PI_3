public interface Imprimivel {
    public abstract void mostrarDados();
}
