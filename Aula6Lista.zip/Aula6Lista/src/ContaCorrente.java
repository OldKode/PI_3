public class ContaCorrente extends ContaBancaria implements Imprimivel{
    
    protected double taxaDeOperacao = 2.5;

    public ContaCorrente(int numeroConta, double saldo) {
        super(numeroConta, saldo);
    }
    
    public double sacar(double valor){
        
        if (getSaldo()< valor+this.taxaDeOperacao){
            System.out.println("Saldo insuficiente para saque.");
            return getSaldo();
        }
        
        setSaldo(getSaldo()- valor - this.taxaDeOperacao);
        return getSaldo();
    }
    
    public double depositar(double valor){
        
        if (valor-this.taxaDeOperacao < 0){
            System.out.println("Deposito permitido somente acima de R$2.50.");
            return getSaldo();
        }
        setSaldo(getSaldo() + valor - this.taxaDeOperacao);
        return getSaldo();
        
    }

    public double gettaxaDeOperacao() {
        return taxaDeOperacao;
    }

    public void settaxaDeOperacao(double taxaDeOperacao) {
        this.taxaDeOperacao = taxaDeOperacao;
    }
    
    public void mostrarDados(){
        System.out.println("Numero:" + getNumeroConta());
        System.out.println("Saldo: " + getSaldo());
        System.out.println("Taxa de Operação: " + gettaxaDeOperacao()+"\n");
    }
}
