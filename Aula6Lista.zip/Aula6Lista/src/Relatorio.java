public class Relatorio {
    
    public void gerarRelatorio(Imprimivel I){
        I.mostrarDados();
    }
    
}
