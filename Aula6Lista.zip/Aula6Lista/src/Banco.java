import java.util.ArrayList;

public class Banco implements Imprimivel{
    private ArrayList<ContaBancaria> contas;

    //inserir, remover e procurarConta
    
    public void inserir(ContaBancaria conta){
        contas.add(conta);
    }
    
    public void remover(ContaBancaria conta){
        contas.remove(conta);
    }
    
    public ContaBancaria procurarConta(ContaBancaria conta){
        for (ContaBancaria contaProcura : this.contas){
            if(contaProcura.equals(conta))
                return contaProcura;
        }
        return null;
    }
    
    public void mostrarDados(){
        for (Imprimivel contaProcura : this.contas){
            contaProcura.mostrarDados();
        }
    }
    
}
