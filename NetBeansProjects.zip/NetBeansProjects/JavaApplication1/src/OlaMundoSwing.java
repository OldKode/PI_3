
/**
 *
 * @author joao.lslima1
 */
public class OlaMundoSwing {
    public static void main(String[] args) {
        Jogo tennis = new Jogo();
        tennis.run();
    }
}
