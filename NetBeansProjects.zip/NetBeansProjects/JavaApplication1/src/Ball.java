import  java.awt.Graphics2D;
/**
 *
 * @author joao.lslima1
 */
public class Ball {
    //Atributos para alterar a posição da bola
    int x = 0;
    int y = 0;
    int xa = 1;
    int ya = 1;
    Jogo jogo;
    
    public Ball(Jogo jogo){
        this.jogo = jogo;
    }
    
    public void paint(Graphics2D g){
        g.fillOval(x, y, 30, 30);
    }
    
    public void move(){
        if (x + xa <0)
            xa = 1;
        if (x + xa > jogo.getWidth() - 30)
            xa = -1;
        if (y + ya <0)
            ya = 1;
        if (y + ya > jogo.getHeight() -30 )
            ya = -1;

        x = x+xa;
        y = y+ya;
    }
}
