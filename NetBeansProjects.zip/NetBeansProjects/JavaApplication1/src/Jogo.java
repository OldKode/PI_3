import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.geom.Ellipse2D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.KeyListener;
/**
 *
 * @author joao.lslima1
 */
public class Jogo extends JPanel implements KeyListener{
    boolean jogoAtivo = true;
    Ball ball;
    public Jogo(){
        JFrame frame = new JFrame("Mini Tennis");
        frame.add(this);
        frame.setSize(300,300);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ball = new Ball(this);
        frame.addKeyListener(this);
    }
    
    public void move(){
        ball.move();
    }

    public void run() {
        while (jogoAtivo) {
            this.move();
            this.repaint();
        try {
            Thread.sleep(10);
        } catch(InterruptedException ex) {}
        
        }
    }
    
    @Override
    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        ball.paint(g2d);
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        // Sem impressao.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("Tecla pressionada: " + e.getKeyChar());
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("Tecla solta: " + e.getKeyChar());
    }

}
