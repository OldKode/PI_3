import javax.swing.JFrame;

/**
 *
 * @author joao.lslima1
 */
/*
public class TesteSwing {
    public static void main(String[] args) {
        //Cria objeto do tipo JFrame
        JFrame frame = new JFrame("Ola Mundo Grafico");
        //Define resolução da tela
        frame.setSize(800,600);
        //Coloca o local "relativo" da tela (Null coloca no meio)
        frame.setLocationRelativeTo(null);
        //Termina o processo ao clicar no X
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Torna a tela visivel.
        frame.setVisible(true);
    }
}
*/