/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package knn;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author joao.lslima1
 */
public class Knn {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        ponto entrada;
        ponto listaDePontos[] = new ponto[10];
        ponto proximos[];         // pega retorno de comparação dos pontos proximos
        int x,y;                // variáveis do ponto informado neste arquivo
        int linhaX,linhaY;      // variáveis auxiliares da leitura
        int contadorPontos = 0; // Variável de indice para inclusão dos pontos recebidos do TXT
        int maxPontos = 0;          // pega quantos pontos o usuário deseja buscar
        
        Scanner input = new Scanner(System.in);

        
        FileReader arquivo = new FileReader("arquivo.txt");
        BufferedReader bufferArquivo = new BufferedReader(arquivo);
        
        System.out.println("arquivo aberto corretamente");
        
        System.out.println("Insira o valor X do ponto:");
        x = input.nextInt();
        System.out.println("Insira o valor Y do ponto:");
        y = input.nextInt();
        
        entrada = new ponto(x,y);
        
        String linha = bufferArquivo.readLine(); // lê a primeira linha
        // a variável "linha" recebe o valor "null" quando o processo
        // de repetição atingir o final do arquivo texto
         while (linha != null) {
            String linhas[] = linha.split(" ");
            // converte a string linha[0] para inteiro
            linhaX = Integer.parseInt(linhas[0]);
            // converte a string linha[1] para inteiro
            linhaY = Integer.parseInt(linhas[1]);
            listaDePontos[contadorPontos] = new ponto(linhaX,linhaY);
            
            linha = bufferArquivo.readLine(); // lê proxima linha
        }
         
         proximos = entrada.proximo(listaDePontos, maxPontos);
         
         for(int ind = 0; ind< proximos.length;ind++){
             System.out.println(ind + "º numero próximo:");
             System.out.println("X - " + proximos[ind].getX() +  "Y - " + proximos[ind].getY());
         }
    }
    
}