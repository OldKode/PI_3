/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package knn;

/**
 *
 * @author joao.lslima1
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class ponto {

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }
    private int x, y;
    
    public ponto(int iniX, int iniY )
    {
    // corpo do construtor
       x = iniX;
       y = iniY;
    }
    
    /*
    public ponto[] proximo(ponto outro[], int limite){
        int [] aux;
        aux = new int[outro.length];
        
        int [] pontoProx;
        pontoProx = new int[limite];
        
        ponto [] retorno;
        retorno = new ponto[limite];
        
        int menor, menorInd;
        boolean achou = false;
        
        //calcula distancia
        for(int lnX = 0; lnX < outro.length;lnX++){
            //aux[lnX] = (int) Math.sqrt(Math.pow((getX() - outro[lnX].getX()),2) + Math.pow((getY() - outro[lnX].getY()),2));
            aux[lnX] = 1;
        }
        //resultado= √(P1. x − P2. x)^2 + (P1. y − P2. y)^2
        
        //percorre a lista de distancias pegando a distancia menor e jogando no vetor pontoprox (na ordem)
        for(int lnIni = 0; lnIni < pontoProx.length; lnIni++){
            menorInd = 0;
            menor = aux[0];
            for(int cont = 0; cont < outro.length; cont++){
                if(aux[cont] < menor){
                    for(int esta = 0; lnIni < pontoProx.length; lnIni++){
                        if (pontoProx[esta] == cont){
                            achou = true;
                        }    
                    }
                    if (!achou){
                        menorInd = cont;
                        menor = aux[cont];
                    }
                }
            }
            pontoProx[lnIni] = menorInd;
        }
        
        for(int ind = 0; ind <= retorno.length; ind++){
            retorno[ind]= outro[pontoProx[ind]];
        }
        
        return retorno;
    }
    */
    
    
}
