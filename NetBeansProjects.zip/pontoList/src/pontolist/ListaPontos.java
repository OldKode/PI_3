package pontolist;
import java.util.ArrayList;

public class ListaPontos{
    private int ultPre;
    ArrayList<Ponto> pontos = new ArrayList();
    
    public void adicionaPonto (Ponto p){
        this.ultPre++;
        this.pontos.add(p);
        //this.pontos[this.ultPre] = p;
    }
    
    public void adicionaPontoIndice(Ponto p, int i){
       this.pontos.add(i, p);
    }
    
    public boolean busca(Ponto p){
        for (Ponto elem : pontos){
            if (elem.igual(p)){
                return true;
            }
        }
        return false;
    }
    
    public Ponto removePonto(int i){
        return this.pontos.remove(i);
    }
    
    public int quantidade(){
        return this.pontos.size();
    }
    
}
