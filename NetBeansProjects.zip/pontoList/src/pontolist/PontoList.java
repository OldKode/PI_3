package pontolist;

/**
 *
 * @author joao.lslima1
 */
public class PontoList {
    public static void main(String[] args) {
        
        

    }
    
}

