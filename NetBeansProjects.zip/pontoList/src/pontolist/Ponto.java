package pontolist;

public class Ponto {
    
    private int x;
    private int y;
    
    void carregaPonto(int x, int y){
        
        this.setX(x);
        this.setY(y);
        
    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }
    
    public boolean igual(Ponto pont){
        if (this.getX() == pont.getX() && this.getY() == pont.getY()){
            return true;
        }
        return false;
    }
}
