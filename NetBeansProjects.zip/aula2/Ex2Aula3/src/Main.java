
import pontolist.ListaPontos;
import pontolist.Ponto;

/**
 *
 * @author matheus.maoki @Author joao.lslima1
 */
public class Main {
    public static void main(String[] args) {
        
        ListaPontos lp = new ListaPontos();
        lp.ListaPontos(10);
        
        Ponto p = new Ponto();  
        p.carregaPonto(0, 0);
        lp.adicionaPonto(p);
        
        Ponto p1 = new Ponto();
        p1.carregaPonto(1, 1);
        lp.adicionaPonto(p1);
        
        Ponto p2 = new Ponto();
        p2.carregaPonto(2, 2);
        lp.adicionaPonto(p2);
        
        Ponto p3 = new Ponto();
        p3.carregaPonto(3, 3);
        lp.adicionaPonto(p3);
        
        Ponto p4 = new Ponto();
        p4.carregaPonto(4, 4);
        lp.adicionaPonto(p4);
        
        lp.removePonto(8);
        System.out.println(lp.pontos[3].getX()+", "+lp.pontos[3].getY());
        
        lp.adicionaPontoIndice(p2, 8);
        System.out.println(lp.pontos[0].getX()+", "+lp.pontos[0].getY());
        System.out.println(lp.pontos[1].getX()+", "+lp.pontos[1].getY());

    }
    
}
