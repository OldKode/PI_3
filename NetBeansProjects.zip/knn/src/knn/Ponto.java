package knn;
import java.util.ArrayList;
import java.util.Collections;
import static java.util.Comparator.comparing;
/**
 *
 * @author joao.lslima1
 */
public class Ponto {
    public int getX() {
        return x;
    }
    
    public void setX(int x) {
        this.x = x;
    }
    
    public int getY() {
        return y;
    }
    
    public void setY(int y) {
        this.y = y;
    }
    
    public int getDist() {
        return dist;
    }

    public void setDist(int dist) {
        this.dist = dist;
    }
    
    private int x,y,dist;
    
    public Ponto(int iniX, int iniY, int dist )
    {
    // corpo do construtor
       x = iniX;
       y = iniY;
       dist = dist;
    }
    
    public boolean compara(Ponto ponto){
        if(this.getX() == ponto.getX() && this.getY() == ponto.getY())
            return true;
        return false;
    }
    
    public ArrayList<Ponto> proximo(ArrayList<Ponto> outro, int limite){
        ArrayList<Ponto>auxiliar = new ArrayList();
        ArrayList<Ponto>pontoProximo = new ArrayList();
        ArrayList<Ponto>retornoDist = new ArrayList();
        
        int menor, menorInd;
        boolean achou = false;
        
        //calcula distancia
        //for(int lnX = 0; lnX < outro.length;lnX++){
           //aux[lnX] = (int) Math.sqrt(Math.pow((getX() - outro[lnX].getX()),2) + Math.pow((getY() - outro[lnX].getY()),2));
        for(Ponto pontoAuxiliar : outro){
            pontoAuxiliar.setDist( (int) Math.sqrt(Math.pow((pontoAuxiliar.getX()-this.getY()),2)+Math.pow((pontoAuxiliar.getY()-this.getY()),2)));
        }
        
        
        
        
        
        
        
    }    
}
