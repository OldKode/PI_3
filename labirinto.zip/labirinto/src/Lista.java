/**
 *
 * @author jlsl4
 */
public class Lista{
    private int qtPontos = -1;
    private int lista[][] = new int[100][3];
        
    public Lista() {
        //int lista[] = new int[100][2];
    }
    
    //insere na lista um registro com: 
    //x - linha
    //y - coluna
    //dist - distancia do "pai"
    public void inserir(int x, int y, int dist){
        this.qtPontos++;
        this.lista[qtPontos][0] = x;
        this.lista[qtPontos][1] = y;
        this.lista[qtPontos][2] = dist;
    }  
    
    //remove da lista e retorna o ponto removido
    public int[] remover(){
        int removido[] =  new int[3];
        removido[0] = this.lista[qtPontos][0];
        removido[1] = this.lista[qtPontos][1];
        removido[2] = this.lista[qtPontos][2];
        this.lista[qtPontos][0] = 0;
        this.lista[qtPontos][1] = 0;
        this.lista[qtPontos][2] = 0;
        this.qtPontos--;
        return removido;
    }
    
    //verifica se está vazia
    public boolean vazia(){
        return this.qtPontos == -1;
    }  
}