import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author João lucas e Julia Martins
 */
public class labirinto {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        int Ax = 0,Ay = 0;          // variáveis do ponto A
        int Bx = 0,By = 0;          // variáveis do ponto B
        int contadorPontos = 0;     // Variável de indice para inclusão dos pontos recebidos do TXT
        int atual[] =  new int[2];  // Variável auxiliar para o ponto "atual"
        
        FileReader arquivo = new FileReader("arquivo.txt");
        BufferedReader bufferArquivo = new BufferedReader(arquivo);
        
        System.out.println("arquivo aberto corretamente");
        
        String linha = bufferArquivo.readLine(); // lê a primeira linha
        int tamanho = linha.length()/2;
        int mapa[][] = new int[tamanho][tamanho]; // gera o mapa de tamanho NxN
        
        //percorre enquanto a linha não estiver nula
        while (linha != null) {
            //divide a linha atual em um array utilizando " " como separador
            String linhas[] = linha.split(" ");
            //percorre o array da linha atual
            for(int i = 0; i < tamanho ; i++){
                mapa[contadorPontos][i] = Integer.parseInt(linhas[i]);
                //caso seja 1, é o inicio
                if(mapa[contadorPontos][i] == 1){
                    Ax = contadorPontos;
                    Ay = i;
                }
                //caso seja -2, é o destino
                if(mapa[contadorPontos][i] == -2){
                    Bx = contadorPontos;
                    By = i;
                }
            }            
            contadorPontos = contadorPontos + 1;
            linha = bufferArquivo.readLine(); // lê proxima linha
        }
        
        //cria lista
        Lista fila = new Lista();
        //coloca o inicio na lista com a distancia de 1
        fila.inserir(Ax, Ay,1);
        
        //enquanto lista não estiver vazia
        while(!fila.vazia()){
            //mostrando atualizações
            /*
            for(int i = 0; i < tamanho; i++){
                for(int j = 0; j < tamanho ; j++){
                    System.out.print(mapa[i][j] + " ");
                }
                System.out.println("");
            }
            System.out.println("-----------------------------------------------");
            */
            
            //remove da lista e devolve ponto
            atual = fila.remover();
            
            //atualiza no mapa o valor de distancia
            mapa[atual[0]][atual[1]] = atual[2];

            //valida se o ponto acima está dentro do range
            if(atual[0]-1 >= 0){
                //se for valido, insere ele na fila
                if(mapa[atual[0]-1][atual[1]] == 0){
                    fila.inserir(atual[0]-1, atual[1],atual[2] + 1);
                }
                //se for o destino, sai do while.
                if(mapa[atual[0]-1][atual[1]] == -2)
                    break;
            }
            
            //valida se o ponto abaixo está dentro do range
            if(atual[0]+1 < tamanho){
                //se for valido, insere ele na fila
                if (mapa[atual[0]+1][atual[1]] == 0){
                    fila.inserir(atual[0]+1, atual[1],atual[2] + 1);
                }
                //se for o destino, sai do while.
                if (mapa[atual[0]+1][atual[1]] == -2)
                    break;
            }
            
            //valida se o ponto a esquerda está dentro do range
            if(atual[1]-1 >=0){
                //se for valido, insere ele na fila
                if(mapa[atual[0]][atual[1]-1] == 0){
                    fila.inserir(atual[0], atual[1]-1,atual[2] + 1);
                }
                //se for o destino, sai do while.
                if(mapa[atual[0]][atual[1]-1] == -2)
                    break;
            }
            
            //valida se o ponto a direita está dentro do range
            if(atual[1]+1 < tamanho){
                //se for valido, insere ele na fila
                if(mapa[atual[0]][atual[1]+1] == 0){
                    fila.inserir(atual[0], atual[1]+1,atual[2] + 1);
                }
                //se for o destino, sai do while.
                if(mapa[atual[0]][atual[1]+1] == -2)
                    break;
            }
        }
        
        //mostrando resultado
        for(int i = 0; i < tamanho; i++){
            for(int j = 0; j < tamanho ; j++){
                System.out.print(mapa[i][j] + " ");
            }
            System.out.println("");
        }
        
    }
        
}