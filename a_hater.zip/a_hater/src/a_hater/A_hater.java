/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a_hater;

/**
 *
 * @author joao.lslima1
 */
public class A_hater {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        No inicio = new No(1,1);        
        No destino = new No(2,1);
        No outro1 = new No();
        No outro2 = new No();
        No outro3 = new No();
        No outro4 = new No();
        inicio.vizinho.add(outro1);
        outro1.vizinho.add(outro2);
        outro2.vizinho.add(outro3);
        outro3.vizinho.add(outro4);
        outro4.vizinho.add(destino);
        
        Estrela a_star = new Estrela();
        System.out.println(a_star.busca(inicio, destino));
    }
    
}