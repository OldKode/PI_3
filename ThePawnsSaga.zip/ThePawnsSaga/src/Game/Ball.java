/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game;

/**
 *
 * @author acronuslg_sup
 */
import java.awt.Graphics2D;

public class Ball {
	int x = 0;
	int y = 0;
	int xa = 0;
	int ya = 0;
        int type = 0;
	private Game game;

	public Ball(Game game, int type) {
		this.game= game;
                this.type = type;
	}

	void move(Racquet player) {
            switch(this.type){            
                case 1: //""""""""""bispo""""""""""""
                    if (this.x > player.x + 40){
                        xa = -1;
                    }else if(this.x < player.x - 40){
                        xa = 1;
                    }

                    if (this.y > player.y + 40){
                        ya = -1;
                    }else if(this.y < player.y - 40){
                        ya = 1;
                    }
                    
                    if (x + xa > game.getWidth() - 30)
			xa = -1;
                    if (y + ya > game.getHeight() - 30)
			ya = -1;

                    x = x + xa;
                    y = y + ya;
                    break;
                case 2://Torre
                    double rnd = Math.random();
                    if (this.y > 400 || ya == 0 ){
                        ya = 0;
                        if (this.x > player.x +2){
                            xa = -1;
                        }else if(this.x < player.x + -2){
                            xa = 1;
                        }else{
                            xa = 0;
                        }
                    }                    
                    if(this.x > 400 || xa == 0 ){
                        if (this.y > player.y){
                            xa = 0;
                            ya = -1;
                        }else if(this.y < player.y){
                            xa = 0;
                            ya = 1;
                        }else{
                            ya = 0;
                        }
                    }
                    
                    
                    if (x + xa > game.getWidth() - 30)
			xa = -1;
                    if (y + ya > game.getHeight() - 30)
			ya = -1;

                    x = x + xa;
                    y = y + ya;
                    break;
            }
	}
        
        void move() {
                
		if (x + xa < 0)
			xa = 1;
		if (x + xa > game.getWidth() - 30)
			xa = -1;
		if (y + ya < 0)
			ya = 1;
		if (y + ya > game.getHeight() - 30)
			ya = -1;
                
		x = x + xa;
		y = y + ya;
	}

	public void paint(Graphics2D g) {
		g.fillOval(x, y, 30, 30);
                /*
                g.fillOval(x+30, y, 5, 5);
                g.fillOval(x-30, y, 5, 5);
                g.fillOval(x, y-30, 5, 5);
                g.fillOval(x, y+30, 5, 5);
                */
	}
        
        public boolean colidiuInimigo(Racquet player, Ball inimigo){
            if (player.x + 50 > inimigo.x && player.x - 30 < inimigo.x)
                if (player.y + 45 > inimigo.y && player.y - 20 < inimigo.y)
                    return true;
            return false;
        }
}